#SXD20|20010|50173|50217|2014.09.05 13:42:18|masterko_bd|0|76|261|
#TA Newsletter`0`0|advice`2`452|articles`0`1404|articles_cat`0`0|articles_img`0`0|banners`0`0|block_ip`0`0|blocks`13`3808|blog`0`0|comments_blog`0`0|faq`0`0|files`0`0|gallery`15`17060|gallery_img`176`3520|htracer_htracer_pages`0`0|htracer_htracer_queries`0`0|logs_adminlogin`0`0|medialib`0`0|medialib_cat`0`0|modules`4`412|modulesPath`3`116|modules_option`10`1556|news`2`304|news_img`0`0|pages`20`71136|poll_ans`0`0|polls`0`0|price`0`0|price_cat`0`0|price_img`0`0|pricelistfiles`0`0|reviews`0`324|settings_shop`0`0|shop_attach`3`39|shop_brands`0`0|shop_cat`0`0|shop_colors`0`0|shop_colors_values`0`0|shop_delivery`0`0|shop_dop`0`0|shop_dop_values`0`0|shop_favorite`0`0|shop_fullness`0`0|shop_fullness_values`0`0|shop_images`0`0|shop_items`0`0|shop_items_comments`0`0|shop_items_comments_img`0`0|shop_items_dop`0`0|shop_items_rating`0`0|shop_orders`0`0|shop_orders_items`0`0|shop_post`0`0|shop_sizes`0`0|shop_sizes_values`0`0|shop_sk_users`0`0|shop_style`0`0|shop_style_values`0`0|shop_tmp`0`0|shop_users`0`0|site_setting`5`124|slider`3`132|slider_img`3`60|specialists`0`0|specialists_img`0`0|stat`0`0|tips`0`16384|userform`0`0|userform_check_items`0`0|userform_formatfiles`0`0|userform_values`0`0|users`2`136|users_portal`0`0|video`0`0|video_img`0`0|widgets`0`0
#EOH

#	TC`Newsletter`utf8_general_ci	;
CREATE TABLE `Newsletter` (
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `name` varchar(255) NOT NULL,
  KEY `subject` (`subject`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`advice`utf8_general_ci	;
CREATE TABLE `advice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `homepage` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `answer` text NOT NULL,
  `active` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`advice`utf8_general_ci	;
INSERT INTO `advice` VALUES 
(1,'1374091200','Немного о натяжном потолке.','alf@ya.ru','','','Натяжной потолок представляет собой идеально ровную поверхность (без учета провисания), получаемую натяжением пленки ПВХ специального состава.','',1),
(5,'1394654400','Вова','fojia@mail.ru','','','Привет. это тестовы совет','',1)	;
#	TC`articles`utf8_general_ci	;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `arts` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TC`articles_cat`utf8_general_ci	;
CREATE TABLE `articles_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL,
  `name` text NOT NULL,
  `desc` text NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`articles_img`utf8_general_ci	;
CREATE TABLE `articles_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`banners`utf8_general_ci	;
CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `type` int(11) NOT NULL DEFAULT '2',
  `bannerType` int(11) NOT NULL DEFAULT '0',
  `width` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`block_ip`cp1251_general_ci	;
CREATE TABLE `block_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`blocks`utf8_general_ci	;
CREATE TABLE `blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`blocks`utf8_general_ci	;
INSERT INTO `blocks` VALUES 
(1,'adres_top','Адрес вверху ','Москва, Ул. Осташкова, 5'),
(2,'tel_top','Телефон вверху','+7 926 001 99 59'),
(3,'logo','Логотип','<img src=\"template/default/img/logo_n.png\" />'),
(4,'soc','Социальные сети','<img alt=\"\" src=\"template/default/img/pic1.png\" />'),
(5,'copy','Копирайт','2013 Студия ремонта &laquo;Мастерков&raquo;.'),
(6,'slogan','Слоган под копирайтом','Ремонт квартир, офисов и коттеджей.'),
(7,'adres_bottom','Адрес внизу','Москва, Анадырский пр., 21'),
(8,'tel_bottom','Телефон внизу','+7 926 001 99 59'),
(9,'email_bottom','Электронная почта внизу ','<a href=\"#\">info@masterkov.ru</a>'),
(10,'design','Дизайн проекты','<p>Мы обеспечиваем индивидуальный подход к каждому клиенту и дадим подробную профессиональную консультацию.</p>'),
(11,'remont','Ремонт квартир','<ul class=\"list470\">\n<li class=\"block470-1\">\n<div><span>Дизайн-проекты</span>\n<p>Мы обеспечиваем индивидуальный подход к каждому клиенту и дадим подробную профессиональную консультацию.</p>\n<a href=\"/dizayn_proekt_kvartiri\">Подробнее</a></div>\n</li>\n<li>\n<div><span>Ремонт квартир</span>\n<p>Мы обеспечиваем индивидуальный подход к каждому клиенту и дадим подробную профессиональную консультацию.</p>\n<a href=\"/uslugi\">Подробнее</a></div>\n</li>\n</ul>'),
(12,'text_main','Текст на главной','<p class=\"title31a\">Устали выбирать компанию для ремонта?</p>\n<p class=\"title31b\">Нужно прочитать Ваши мысли? Создать интерьер, как Вы хотите?</p>\n<p>Уделяя внимание мелочам? Максимально аккуратно? Разрешите представиться &ndash; Компания Мастерков! Современные технологии, лучшие отделочные материалы, оптимальные решения.</p>\n<div class=\"adv31\">\n<p><span>Преимущества работы с нами:</span></p>\n<ul>\n<li>Мы небольшая компания,а значит, Вы не поставлены на поток</li>\n<li>Открытая и понятная схема расчета цены и покупки материала</li>\n<li>Вы получаете максимальные скидки на отделочные материалы</li>\n<li>Гарантия 2 года. На электрическую и сантехническую части 3 года</li>\n<li>В Ваших квартирах никто не будет курить.</li>\n<li>На Ваших объектах никто не будет проживать.</li>\n</ul>\n<p><span><a href=\"/ceni\">Как узнать цену?</a></span></p>\n</div>'),
(13,'garantii','Гарантии на главной','<p><span>Гарантии</span></p>\n<p>Наша деятельность ведется официально. С Вами заключается договор. Риски неисполнения или некачественного исполнения исключены. Все работы выполняются в соответствии с международными технологиями и стандартами. О качестве выполнения работ читайте в <a href=\"/reviews\">отзывах</a>.</p>')	;
#	TC`blog`utf8_general_ci	;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` text CHARACTER SET cp1251 NOT NULL,
  `title` text CHARACTER SET cp1251 NOT NULL,
  `anons` text NOT NULL,
  `text` text CHARACTER SET cp1251 NOT NULL,
  `full` text CHARACTER SET cp1251 NOT NULL,
  `active` int(11) NOT NULL DEFAULT '2',
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`comments_blog`utf8_general_ci	;
CREATE TABLE `comments_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`faq`utf8_general_ci	;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `homepage` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `answer` text NOT NULL,
  `active` int(11) NOT NULL DEFAULT '2',
  `mail` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`files`utf8_general_ci	;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `fulldesc` text NOT NULL,
  `ext` varchar(255) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0',
  `shortdesc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`gallery`utf8_general_ci	;
CREATE TABLE `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `types` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8	;
#	TD`gallery`utf8_general_ci	;
INSERT INTO `gallery` VALUES 
(1,0,0,'2013-12-04','г. Химки, ул. Калинина д.5','','<h1>Жк 12 квартал</h1>\nЗаказчики, молодая семья с маленьким сыном, никак не могли определиться с общей стилистикой квартиры. От модных, экстравагантных, цветных проектов решили отказаться и пришли к логичному и правильному решению создать спокойный интерьер. Комфорт и рациональное использование пространства легли в основу будущей квартиры. Радиусная дверь-перегородка в кухню-столовую позволила выкроить дополнительное место для небольшой гардеробной. В гостиной внимание привлекает диван, на котором свободно размещается семья и их гости. Собственно, функция гостиной сводится к общению и просмотру фильмов. Спальня максимально располагает к отдыху, но при этом не лишена декоративных приемов &ndash; изголовье кровати украшает художественное панно.<br /><br />При видимой простоте форм все элементы интерьера выполнены из изысканных материалов. Использованы дорогие породы дерева в отделке пола, в кухонном гарнитуре, мрамор в слэбах на стенах ванной.','','','',1,0),
(2,0,0,'2013-12-05','Ремонт квартиры на Арбате','Тестовое описание ','Описание тестового ремонта','','','',0,0),
(3,0,0,'2013-12-05',' Ремонт коттеджа на Рублевке 12 мая 2013','Аноннс тестового описание ','Полное тестовое описание','','','',0,1),
(4,0,0,'2013-12-05','Ремонт офиса «Уральские пельмени»','Анонс тестового замечания ','Полное описание тестового описания','','','',0,0),
(5,0,0,'2013-12-05','Ремонт офиса на грохольском переулке','','','','','',0,0),
(10,0,0,'0000-00-00','','','','','','',0,0),
(7,0,0,'0000-00-00','','','','','','',0,0),
(9,0,0,'0000-00-00','','','','','','',0,0),
(11,0,0,'2013-12-18','Гранд парк','','<p style=\"text-align: justify;\"><b>Ж\\к Гранд парк</b></p>\n<p style=\"text-align: justify;\">Владельцы этой квартиры - энергичные общительные люди. Они стремятся ко всему новому, поэтому сразу поставили условие: \"Нам нужна модная и современная квартира\". Главное в этом интерьере - уникальная игра цвета в сочетании с современным дизайном. Терракотовые стены, насыщенного сложного оттенка стали отправной точкой в цветовом дизайне центральной части квартиры. Дорожка из мозаики соединяет между собой прихожую и кухню. Спальня получилась очень романтичной. Это помещение должно быть спокойным, настраивать на расслабление и отдых. Но заказчица выразила желание расписать одну из стен цветами, поэтому интерьер получился очень необычным. Так же тема росписи, а точнее граффити появилась и в комнате сына, но тут она выполнена на \"кирпичной\" стене, что придает комнате некоторую урбанистичность. В целом дизайн интерьера квартиры получился свежим, ярким и оригинальным.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/grand_park.pdf\">Планировка.pdf</a></p>','','','',1,1),
(12,0,0,'2013-12-18','Кунцево','','<p style=\"text-align: justify;\"><b>Жк Кунцево</b></p>\n<p style=\"text-align: justify;\"><b>&nbsp;</b>Проектируя эти апартаменты, мы поставили перед собой цель&nbsp;- максимально открыть жилое пространство естественному свету, увеличили размер одного окна и все основные помещения в квартире сделали незамкнутыми, сообщающимися друг с другом, чтобы на пути у солнечных лучей возникало как можно меньше преград. Отделка квартиры тоже была подчинена главной цели. Все стены выкрашены в ровный белый цвет и отражают солнечные лучи, при этом локальные вставки из натурального камня придают интерьеру индивидуальность и респектабельность. Немаловажно, что благодаря открытой планировке нам удалось визуально раздвинуть границы жилой зоны. Весьма обширной получилась спальня, находящаяся в одном объеме с ванной, она характерна перетекающими друг в друга объемами из натурального камня. Но особенно просторно выглядит гостиная. Она объединена со столовой и кухней. Кроме того, благодаря расширенным оконным проемам ее логическим продолжением стала еще и лоджия. Немаловажная роль была уделена дизайну дверей и шкафов &ndash; они максимально высокие и из-за отсутствия наличников практически незаметны.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/kuncevo.pdf\">Планировка.pdf</a></p>','','','',1,0),
(13,0,0,'2013-12-18','Нагорная','','<p style=\"text-align: justify;\"><b>Нагорная</b></p>\n<p style=\"text-align: justify;\">Хозяйка этой небольшой квартиры, молодая активная девушка, точно знала, что хочет создать в своем новом жилище уголок прованса. Работа шла очень легко, эскизы встречались заказчицей с воодушевлением и радостно утверждались.&nbsp; &nbsp;</p>\n<p style=\"text-align: justify;\">Интерьер этой квартиры стал своеобразным диалогом пространств. Между основными помещениями нет дверей и раздвижных перегородок. Заказчица не хотела резать пространство возводимыми стенами. Так например спальню и гостиную разделяет воздушная ажурная перегородка-ширма. В квартире изначально были очень высокие потолки, что позволило их декорировать строганной доской и деревянными балками в соответствии с выбранным стилем. Практически все стены решено было выкрасить декоративной штукатуркой в единый бледно-зеленый цвет, только за изголовьем кровати акцентирована стена узорными обоями. В декоре использовано множество картин и фотографий, а так же цветовые акценты добавляют разноцветные подушки.<a href=\"/upload-files/nagorna.pdf\"><br /></a></p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/nagorna.pdf\">Планировка.pdf</a></p>\n<p style=\"text-align: justify;\"><b>&nbsp;</b></p>','','','',1,0),
(14,0,0,'2013-12-18','Наличная','','<p style=\"text-align: justify;\"><b>Наличная</b></p>\n<p style=\"text-align: justify;\">Хозяйка квартиры &ndash; молодая девушка, человек разносторонних интересов, который много путешествует и увлекается искусством. Динамичный образ жизни заказчицы диктовал свои условия в организации пространства квартиры: она должна была быть максимально комфортной, просторной, без большого количества углов и распашных дверей, с вместительной гардеробной, удобной и лаконичной кухней, переходящей в зону гостиной, небольшой, но уютной спальней. В процессе реализации не возникало никаких разногласий и споров, все решения приходили довольно быстро, и проект сдался в минимальные сроки. Заказчица хотела уйти от банальных бежевых интерьеров и наполнить каждое помещение особым настроением, чему способствуют контрастные покрытия стен. Яркая кухня поднимает настроение и разжигает аппетит, фиолетовая гостиная настраивает на приятное времяпрепровождение в кругу дружеской компании, на балконе по просьбе заказчицы устроен мягкий уголок для чтения, а спальня располагает к спокойному отдыху.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/nal.pdf\">Планировка.pdf</a></p>\n<p style=\"text-align: justify;\">&nbsp;</p>','','','',1,0),
(15,0,0,'2013-12-18','Новопеределкино','','<p style=\"text-align: justify;\"><b>Новопеределкино</b></p>\n<p style=\"text-align: justify;\">Эта большая светлая квартира получилась путем объединения двух соседних. Семейная пара с двумя очаровательными дочерьми и мечтающая еще об одном ребенке хотела видеть свое будущее жилище светлым, уютным, спокойным, максимально комфортабельным, располагающим к отдыху большой дружной семьи, но в то же время, чтобы у каждого ее члена была своя территория. Так у каждого ребенка появилась своя индивидуальная и неповторимая комната. А общий дизайн квартиры решено было выдержать в &laquo;современном&raquo; классическом стиле, с элегантными белыми дверьми, широкими карнизами, разными уровнями освещения. Из холла в гостиную ведут двери с красивыми витражными вставками. Палитра интерьера построена на сочетании кремовых и шоколадных оттенков, являющихся основными цветами мебели, текстиля и паркета. Дозированное использование активных цветовых пятен&nbsp;- в основном это шторы, декоративные подушки живопись и небольшие вкрапления в декоре&nbsp;- освежает общий нейтральный колорит.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/nov.pdf\">Планировка.pdf</a></p>','','','',1,1),
(16,0,0,'2013-12-18','Тверская','','<p style=\"text-align: justify;\"><b>Тверская</b></p>\n<p style=\"text-align: justify;\">Хозяева этой квартиры в центре Москвы - молодая пара с двумя маленькими дочками, долго жили в Европе. Мы искали стилистику интерьера, чтобы он был индивидуальным и точно соответствовал мироощущению и образу жизни семьи. В&nbsp;итоге мы пришли к пониманию, что это должна быть современная европейская квартира&nbsp;- функциональная, эргономичная, обставленная удобной дизайнерской мебелью и выполненная при помощи качественных, исключительно натуральных материалов. Все стены в квартире (кроме детской) выкрашены в белый цвет, он выгодно подчеркивает фактуры и цвета декоративных поверхностей. Так например одна стена в гостиной решена локально чередованием зеркал и деревянных балок, а на противоположной стене декоративной штукатуркой создан эффект травертиновых плит. Во всех помещениях использован только шпон ореха, что создает целостность всего интерьера. В санузлах яркие акценты добавляет дизайнерская плитка.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/tver.pdf\">Планировка.pdf</a></p>\n<p style=\"text-align: justify;\">&nbsp;</p>','','','',1,0),
(17,0,0,'2013-12-18','Дом на Яузе','','<p style=\"text-align: justify;\"><b>Дом на Яузе</b></p>\n<p style=\"text-align: justify;\">Сдержанный и аристократичный по цвету и по форме интерьер повторяет характер заказчиков, которые хотели, чтобы квартира была выдержана в духе спокойной, аристократичной американской классики. Она предназначалась для семьи с двумя дочерьми. Основным пожеланием заказчиков было сделать жилое пространство максимально функциональным, что отразилось прежде всего на планировке. Спальни расположены на одной линии, между ними находится ванная комната и гардеробная. Гостиная и кухня-столовая, представляющие собой одно помещение из-за отсутствия дверей, специальным образом зонированы, вынесены отдельно. Особое место занимает библиотека с электрокамином, подчеркивающая общий классический стиль интерьера. Центром хозяйской спальни несомненно является кровать с высоким изголовьем. Камерность интерьеру придают текстильные обои темного серо-фиолетового оттенка, а светлые плотные шторы, настольные лампы и торшер помогают уйти от ощущения мрачности. В интерьере использованы натуральные материалы &ndash; массивная доска, мрамор на полу в кухне и прихожей, оникс в ванной.</p>\n<p style=\"text-align: justify;\"><a href=\"/upload-files/yzy.pdf\">Планировка.pdf</a></p>\n<p style=\"text-align: justify;\">&nbsp;</p>','','','',1,0)	;
#	TC`gallery_img`utf8_general_ci	;
CREATE TABLE `gallery_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  `itog` tinyint(1) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=230 DEFAULT CHARSET=utf8	;
#	TD`gallery_img`utf8_general_ci	;
INSERT INTO `gallery_img` VALUES 
(21,1,'jpg',0,0,0),
(2,2,'jpg',0,0,0),
(3,3,'jpg',0,0,0),
(4,4,'jpg',1,0,0),
(20,1,'jpg',0,0,0),
(19,1,'jpg',0,0,0),
(18,1,'jpg',0,0,0),
(9,2,'jpg',1,0,0),
(10,2,'jpeg',0,0,0),
(11,2,'jpg',0,0,0),
(12,3,'jpeg',0,0,0),
(13,3,'jpg',0,0,0),
(14,3,'jpg',1,0,0),
(15,4,'jpg',0,0,0),
(16,4,'jpg',0,0,0),
(17,5,'jpg',0,0,0),
(22,1,'jpg',0,0,0),
(23,1,'jpg',1,0,0),
(24,1,'jpg',0,0,0),
(25,1,'jpg',0,0,0),
(26,1,'jpg',0,0,0),
(27,1,'jpg',0,0,0),
(28,1,'jpg',0,0,0),
(29,1,'jpg',0,0,0),
(30,1,'jpg',0,0,0),
(31,1,'jpg',0,0,0),
(32,1,'jpg',0,0,0),
(33,1,'jpg',0,0,0),
(34,1,'jpg',0,0,0),
(35,1,'jpg',0,0,0),
(36,1,'jpg',0,0,0),
(37,1,'jpg',0,0,1),
(38,1,'jpg',0,0,1),
(39,1,'jpg',0,0,1),
(40,1,'jpg',0,0,1),
(41,1,'jpg',0,0,1),
(42,1,'jpg',0,0,1),
(43,1,'jpg',0,0,0),
(44,1,'jpg',0,0,0),
(100,11,'jpg',1,0,0),
(99,11,'jpg',0,0,0),
(98,11,'jpg',0,0,0),
(97,11,'jpg',0,0,0),
(96,11,'jpg',0,0,0),
(95,11,'jpg',0,0,0),
(94,11,'jpg',0,0,0),
(93,11,'jpg',0,0,0),
(101,11,'jpg',0,0,0),
(102,11,'jpg',0,0,0),
(103,11,'jpg',0,0,0),
(104,11,'jpg',0,0,0),
(105,11,'jpg',0,0,0),
(106,11,'jpg',0,0,0),
(107,11,'jpg',0,0,0),
(108,11,'jpg',0,0,0),
(109,11,'jpg',0,0,0),
(110,11,'jpg',0,0,0),
(111,11,'jpg',0,0,0),
(112,11,'jpg',0,0,0),
(113,11,'jpg',0,0,0),
(114,12,'jpg',0,0,0),
(115,12,'jpg',0,0,0),
(116,12,'jpg',0,0,0),
(117,12,'jpg',0,0,0),
(118,12,'jpg',0,0,0),
(119,12,'jpg',0,0,0),
(120,12,'jpg',0,0,0),
(121,12,'jpg',0,0,0),
(122,12,'jpg',0,0,0),
(123,12,'jpg',0,0,0),
(124,12,'jpg',0,0,0),
(125,12,'jpg',0,0,0),
(126,12,'jpg',0,0,0),
(127,12,'jpg',0,0,0),
(128,12,'jpg',1,0,0),
(129,12,'jpg',0,0,0),
(130,12,'jpg',0,0,0),
(131,12,'jpg',0,0,0),
(132,12,'jpg',0,0,0),
(133,13,'jpg',0,0,0),
(134,13,'jpg',1,0,0),
(135,13,'jpg',0,0,0),
(136,13,'jpg',0,0,0),
(137,13,'jpg',0,0,0),
(138,13,'jpg',0,0,0),
(139,13,'jpg',0,0,0),
(140,13,'jpg',0,0,0),
(141,13,'jpg',0,0,0),
(142,13,'jpg',0,0,0),
(143,13,'jpg',0,0,0),
(144,13,'jpg',0,0,0),
(145,13,'jpg',0,0,0),
(146,13,'jpg',0,0,0),
(147,13,'jpg',0,0,0),
(148,14,'jpg',0,0,0),
(149,14,'jpg',0,0,0),
(150,14,'jpg',0,0,0),
(151,14,'jpg',0,0,0),
(152,14,'jpg',0,0,0),
(153,14,'jpg',0,0,0),
(154,14,'jpg',0,0,0),
(155,14,'jpg',0,0,0),
(156,14,'jpg',0,0,0),
(157,14,'jpg',0,0,0),
(158,14,'jpg',0,0,0),
(159,14,'jpg',0,0,0),
(160,14,'jpg',0,0,0),
(161,14,'jpg',0,0,0),
(162,14,'jpg',0,0,0),
(163,14,'jpg',0,0,0),
(164,14,'jpg',0,0,0),
(165,14,'jpg',0,0,0),
(166,15,'jpg',0,0,0),
(167,15,'jpg',0,0,0),
(168,15,'jpg',0,0,0),
(169,15,'jpg',0,0,0),
(170,15,'jpg',0,0,0),
(171,15,'jpg',0,0,0),
(172,15,'jpg',0,0,0),
(173,15,'jpg',0,0,0),
(174,15,'jpg',0,0,0),
(175,15,'jpg',0,0,0),
(176,15,'jpg',0,0,0),
(177,15,'jpg',0,0,0),
(178,15,'jpg',0,0,0),
(179,15,'jpg',0,0,0),
(180,15,'jpg',0,0,0),
(181,15,'jpg',0,0,0),
(182,15,'jpg',0,0,0),
(183,15,'jpg',0,0,0),
(184,15,'jpg',0,0,0),
(185,15,'jpg',0,0,0),
(186,15,'jpg',0,0,0),
(187,15,'jpg',0,0,0),
(188,15,'jpg',0,0,0),
(189,15,'jpg',0,0,0),
(190,15,'jpg',0,0,0),
(191,15,'jpg',0,0,0),
(192,15,'jpg',0,0,0),
(193,15,'jpg',0,0,0),
(194,16,'jpg',0,0,0),
(195,16,'jpg',0,0,0),
(196,16,'jpg',0,0,0),
(197,16,'jpg',0,0,0),
(198,16,'jpg',0,0,0),
(199,16,'jpg',0,0,0),
(200,16,'jpg',0,0,0),
(201,16,'jpg',0,0,0),
(202,16,'jpg',0,0,0),
(203,16,'jpg',0,0,0),
(204,16,'jpg',0,0,0),
(205,16,'jpg',0,0,0),
(206,16,'jpg',0,0,0),
(207,16,'jpg',0,0,0),
(208,16,'jpg',0,0,0),
(209,16,'jpg',0,0,0),
(210,17,'jpg',0,0,0),
(211,17,'jpg',0,0,0),
(212,17,'jpg',0,0,0),
(213,17,'jpg',0,0,0),
(214,17,'jpg',0,0,0),
(215,17,'jpg',0,0,0),
(216,17,'jpg',0,0,0),
(217,17,'jpg',0,0,0),
(218,17,'jpg',0,0,0),
(219,17,'jpg',0,0,0),
(220,17,'jpg',0,0,0),
(221,17,'jpg',0,0,0),
(222,17,'jpg',0,0,0),
(223,17,'jpg',0,0,0),
(224,17,'jpg',0,0,0),
(225,17,'jpg',0,0,0),
(226,17,'jpg',0,0,0),
(227,17,'jpg',0,0,0),
(228,17,'jpg',0,0,0),
(229,17,'jpg',0,0,0)	;
#	TC`htracer_htracer_pages`utf8_bin	;
CREATE TABLE `htracer_htracer_pages` (
  `ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `URL` text COLLATE utf8_bin NOT NULL COMMENT 'PAGE URI (/page1.html)',
  `URL_CS` varbinary(32) NOT NULL COMMENT 'MD5 of URI',
  `Eva` float unsigned NOT NULL DEFAULT '0' COMMENT 'Weigth of page (summ keys weigth)',
  `Eva15` mediumint(9) unsigned NOT NULL DEFAULT '0' COMMENT 'LogRound(1.5, Eva)',
  `FirstKey` varbinary(255) NOT NULL COMMENT 'Source of key with maximum weigth',
  `SecondKey` varbinary(255) NOT NULL COMMENT 'Source of second key with max weigth',
  `ShowInCloud` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'show this page in cloud',
  `ShowATitle` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'add alts to this page',
  `isFirstKeysSetByUser` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `A_Title` (`URL_CS`,`ShowATitle`,`FirstKey`,`SecondKey`),
  KEY `Cloud` (`ShowInCloud`,`Eva15`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`htracer_htracer_queries`utf8_bin	;
CREATE TABLE `htracer_htracer_queries` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `In` varbinary(255) NOT NULL COMMENT 'Key String',
  `Out` varbinary(255) NOT NULL COMMENT 'Sanitarized Key String',
  `Eva` float NOT NULL DEFAULT '0' COMMENT 'Weigth',
  `URL_CS` varbinary(32) NOT NULL COMMENT 'Link to htracer_pages',
  `OutEva` float NOT NULL DEFAULT '0' COMMENT 'Current weigth of Key	(updated when htracer_pages.Eva15 changed)',
  `Version` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT 'ID of HTracer version that change Out or Status. User=10000',
  `Status` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '0 - disabled, 1 - enabled, 2 - moved to another page',
  `ShowInCLinks` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Is this key Enabled in forming contex links',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `KeyAndURL` (`In`,`URL_CS`),
  KEY `OutEva` (`OutEva`),
  KEY `Status` (`Status`),
  KEY `CurentPage` (`URL_CS`,`Status`,`OutEva`,`Out`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`logs_adminlogin`utf8_general_ci	;
CREATE TABLE `logs_adminlogin` (
  `Ip` varchar(255) NOT NULL,
  `Time` text NOT NULL,
  KEY `Ip` (`Ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`medialib`cp1251_general_ci	;
CREATE TABLE `medialib` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`medialib_cat`cp1251_general_ci	;
CREATE TABLE `medialib_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `par` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`modules`utf8_general_ci	;
CREATE TABLE `modules` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text NOT NULL,
  `Module_Icon` varchar(255) NOT NULL,
  `ModuleID` varchar(255) NOT NULL,
  `modulePath` varchar(255) NOT NULL,
  `File` varchar(255) NOT NULL,
  `Active` int(11) NOT NULL,
  `Version` varchar(255) NOT NULL,
  `isGlobal` int(11) NOT NULL,
  `Pos` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8	;
#	TD`modules`utf8_general_ci	;
INSERT INTO `modules` VALUES 
(2,'Основные разделы','pages','pages','Разделы сайта','pages.js',1,'1.2',1,0),
(10,'Блоки','core/icons/package.png','blocks','Управление дизайном','blocks.js',1,'1.0',0,0),
(19,'Новости','core/icons/date.png','news','Разделы сайта','news.js',1,'1.2',0,1),
(20,'Статьи','core/icons/page_copy.png','articles','Разделы сайта','articles.js',1,'1.0',0,3)	;
#	TC`modulesPath`utf8_general_ci	;
CREATE TABLE `modulesPath` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Pos` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`modulesPath`utf8_general_ci	;
INSERT INTO `modulesPath` VALUES 
(1,'Разделы сайта',0),
(2,'Управление дизайном',10),
(4,'Магазин',3)	;
#	TC`modules_option`utf8_general_ci	;
CREATE TABLE `modules_option` (
  `module` varchar(255) NOT NULL,
  `option` varchar(255) NOT NULL,
  `value` text NOT NULL,
  KEY `module` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`modules_option`utf8_general_ci	;
INSERT INTO `modules_option` VALUES 
('pages','Design','<div class=\"text\">{text}</div>'),
('pages','help','<b>{ID}</b> - Выводит индификатор страницы<br>\r\n<b>{TITLE}</b> - Выводить заголовок страницы<br>\r\n<b>{TEXT}</b> - Выводит текст страницы'),
('news','per_page','10'),
('news','design_one','<div class=\'text\'>\n<p><strong>{title}</strong><br />\n{full} <br />\n<span class=\"date\">{date}</span></p>\n      <p align=\"right\" class=\"news_bot\"><a href=\"?news\" class=\"red\">вернуться к списку новостей</a></p>\n</div>'),
('news','design_all','<div class=\'text\'>\n <p align=\"center\">Страницы:\n        {pages}</p>\n\n{while}\n<p><span class=\"date\">{date}</span><br />\n        <strong>{title}</strong><br />\n     {text} <a href=\"?news={id}\" class=\"red\">читать далее &gt;&gt;&gt;</a></p>\n      \n{/while}\n<p>&nbsp;</p>\n<br/>\n <p align=\"center\">Страницы:\n        {pages}</p>\n</div>'),
('news','name_mod','Новости'),
('articles','name_mod','О продукции'),
('articles','per_page','10'),
('articles','design_one','<p><strong>{title}</strong><br />\n{full}\n <br />\n      </p>\n      <p align=\"right\" class=\"news_bot\"><a href=\"?articles\" class=\"red\">вернуться в раздел</a></p>\n'),
('articles','design_all',' <p align=\"center\">Страница<br />\n{pages}\n</p>\n\n{while}\n<p><strong>{title}</strong><br />\n          {text}<br />\n          <a href=\"?articles={id}\" class=\"yel\">Подробнее</a></p>\n{/while}\n<p>&nbsp;</p>\n <p align=\"center\">Страница<br />\n{pages}\n</p>')	;
#	TC`news`utf8_general_ci	;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `arts` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`news`utf8_general_ci	;
INSERT INTO `news` VALUES 
(1,0,0,'2013-07-10','Новость 1 ','Это анонс первой новости ','Это полное описание первой новости','','','',1,''),
(2,0,0,'2013-07-10','Новость 2 ','Это анонс второй новости ','Тут полный текст новости','','','',1,'')	;
#	TC`news_img`utf8_general_ci	;
CREATE TABLE `news_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`pages`utf8_general_ci	;
CREATE TABLE `pages` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Text` longtext NOT NULL,
  `secondTitle` varchar(255) NOT NULL,
  `textblock` text NOT NULL,
  `module` int(11) NOT NULL DEFAULT '0',
  `Title_Page` text NOT NULL,
  `Keys_Page` text NOT NULL,
  `Desc_Page` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `copy` varchar(255) NOT NULL,
  `inMenu` int(3) NOT NULL DEFAULT '0',
  `isService` int(3) NOT NULL DEFAULT '0',
  `Active` int(11) NOT NULL DEFAULT '1',
  `OnIndex` int(11) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL,
  `gallery` int(11) NOT NULL DEFAULT '0',
  `arts` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8	;
#	TD`pages`utf8_general_ci	;
INSERT INTO `pages` VALUES 
(1,0,'Главная ','<h1>Ремонт от простого до царского!</h1>\r\n<p>Семейное Домашнее Счастье? Где же его найти&hellip;?</p>\r\n<p>Конечно в домашней обстановке, наполненной теплом и уютом, в кругу любимых людей. Найдите свое счастье сегодня! Компания г. Москвы &laquo;СДС РемСтрой&raquo; предлагает своим клиентам весь комплекс услуг, связанных с недвижимостью. Здесь Вы найдете полный спектр риэлторских услуг: продажа квартир, аренда квартир, купить квартиру, сдать квартиру, снять квартиру в Москве. Ремонт квартир в Москве под ключ от косметического до элитного, ремонт и отделка офисов, нежилых помещений.</p>','','',0,'','','','','',0,0,1,1,'',0,''),
(2,0,'О компании ','<img alt=\"\" src=\"template/default/img/advice-pic.png\" class=\"advice-pic-in\" />\r\n<p>Какая бы не была квартира &ndash; маленькая или огромная, все равно хочется, чтобы она была по-настоящему удобной для жизни. Ну а та планировка, что задана в типовых квартирах, далеко не всегда соответствует нашему представлению об идеальном жилье, вот и становится все более и более востребованной такая услуга, как перепланировка квартир.</p>\r\n<p>Данная услуга представляет собой целый комплекс работ, включающий в себя: проектирование, согласование, а также строительные, отделочные и другие работы, которые обычно выполняют специализированные предприятия. У них есть подготовленные специалисты, способные осуществить грамотную подготовку и саму перепланировку, но есть некоторые нюансы, решать которые лучше всего вам самим, как хозяину жилья.</p>\r\n<p>Первое, на что необходимо обратить внимание, это расчет необходимого вам свобоного <br />пространства. Предусмотренных государством 18 квадратных метров явно недостаточно &ndash; желательно хотя бы 40, а в идеале и все 60. Ведь именно эти размеры позволяют учитывать необходимые функциональные зоны, стиль жизни, эргономичность и другие факторы, влияющие на необходимую площадь личного пространства.</p>\r\n<img alt=\"\" src=\"template/default/img/pic6.jpg\" class=\"img-left\" />\r\n<p>Далее стоит представить себе как будет освещена ваша квартира. Не стоит пробивать новые окна в стенах, но вот увеличить существующие возможность есть. Если у вас за окном тихий красивый вид, то это вполне оправданное решение, однако если окна выходят на шумную магистраль крупного города, то стоит учитывать повышенный уровень шумов, и воздержаться от панорамного вида. Учитывайте также и то, что какая бы современная конструкция не была у окон, они никогда не сравнятся по уровню теплоизоляции со стенами, и увеличение оконных проемов повлечет за собой дополнительную теплопотерю и необходимость в установке дополнительных обогревательных систем.</p>\r\n<p>Следующим этапом стоит задуматься о том, как правильно распорядиться имеющимся пространством. Практика показывает, что наибольшего расширения требуют те комнаты, которые больше всего используют жильцы.</p>\r\n<br />\r\n<h2>Подарите себе кусочек звездного неба! (h2)</h2>\r\n<p><strong>Удиви гостей присутствием квездного неба в своеё квартире (li);</strong></p>\r\n<ul>\r\n<li>реалистичная имитация звездного неба;</li>\r\n<li>возможность создать эксклюзивный натяжной потолок благодаря комбинации различных приемов;</li>\r\n<li>роскошный, стильный, экстравагантный внешний вид;</li>\r\n<li>широкая область применения &ndash; в квартирах, загородных домах, офисах, магазинах, клубах, ресторанах, бассейнах, саунах и т.д.</li>\r\n</ul>\r\n<p><strong>Удиви гостей присутствием квездного неба в своеё квартире (li);</strong></p>\r\n<ol>\r\n<li>реалистичная имитация звездного неба;</li>\r\n<li>возможность создать эксклюзивный натяжной потолок благодаря комбинации различных приемов;</li>\r\n<li>роскошный, стильный, экстравагантный внешний вид;</li>\r\n<li>широкая область применения &ndash; в квартирах, загородных домах, офисах, магазинах, клубах, ресторанах, бассейнах, саунах и т.д.</li>\r\n</ol>\r\n<p>Немаловажна и роль мебели, предметы которой должны легко переставляться, перемещаться по квартире, трансформируя пространство. <em>Журнальный столик на колесиках</em>, за которым при необходимости можно и перекусить, легко отодвигается в сторону, давая возможность разложить диван-кровать. Мебель-трансформер &mdash; это тоже очень функционально, например складные стулья на кухне, кресло-кровать в гостиной. К трансформерам относятся всевозможные поворотные элементы, раздвижные перегородки.</p>\r\n<blockquote>Для того чтобы максимально упростить себе все хлопоты по ремонту, необходимо обратиться в надежную компанию, кото раявыполнит все работы под ключ и не заставит волноваться, что не исключено при возникновении недоразумений в случае сотрудничества с нерадивыми специалистами.</blockquote>','','',0,'','','','','',0,0,1,0,'',0,''),
(3,0,'Контакты ','<p>+7 926 001 99 59<br /> Москва, Анадырский пр., 21<br /> <a href=\"mailto:info@masterkov.ru\">info@masterkov.ru</a></p>\r\n<script type=\"text/javascript\" charset=\"utf-8\" src=\"//api-maps.yandex.ru/services/constructor/1.0/js/?sid=qfNhYh_L24GWiNksTdpuYX485CUXi8ZR&amp;width=600&amp;height=450\" xml=\"space\"></script>','','',0,'','','','','',0,0,1,0,'',0,''),
(4,0,'Услуги','<p>Дом для каждого человека &ndash; место, куда хочется возвращаться после работы, где можно отдохнуть и с комфортом провести время. Естественно желание сделать свой дом лучше, красивее и обязательно непохожим на все остальные. Компания &laquo;Мастерков&raquo; предлагает свои услуги по составлению дизайн проектов для любых квартир, коттеджей, офисных помещений.</p>\r\n<p>На основании ваших пожеланий и с учётом вашего видения идеального дизайна мы разработаем концепцию будущего дома со всеми интерьерными решениями, представим трёхмерную графическую визуализацию проекта и займёмся планировочными работами &ndash; составим чертежи, проекты.</p>\r\n<p>Студия ремонта &laquo;Мастерков&raquo; также предлагает свои услуги по всем видам отделочных и монтажных работ. В их числе:</p>\r\n<ul>\r\n<li>плотницкие работы (сверление, шлифование, резка древесины);</li>\r\n<li>плиточные работы (облицовка стен плиткой, резка плитки);</li>\r\n<li>демонтажные работы (снос стен, перегородок, снятие окон, дверей);</li>\r\n<li>гипсокартонные работы и возведение межкомнатных перегородок (монтаж гипсокартонных конструкций на потолки и стены);</li>\r\n<li>широкий перечень сантехнических и электрических работ (прокладка канализации, монтаж труб отопления и водоснабжения, установка сантехнической посуды, установка розеток, прокладка проводки и электросетей);</li>\r\n<li>стяжка пола (заливка, выравнивание);</li>\r\n<li>малярные работы (штукатурка, нанесение финишных покрытий);</li>\r\n<li>нанесение декоративных покрытий (штукатурки) и поклейка обоев.</li>\r\n</ul>\r\n<p>Все эти виды работ требуют высокого профессионализма и ответственного подхода к их исполнению. Работы любой сложности специалисты студии ремонта &laquo;Мастерков&raquo; выполнят качественно и точно в срок. Сотрудники нашей компании обладают большим опытом в сфере дизайна помещений и ремонта, благодаря которому смогут обустроить уютный дом, о котором вы всегда мечтали.</p>','Услуги компании','',0,'Услуги студии ремонта Мастерков','','','','',0,1,1,0,'',0,''),
(5,4,'Дизайн-проекты','Раздел в разработке','','',0,'','','','','',0,1,1,0,'',0,''),
(6,5,'Дизайн проект квартиры','<p>Составление дизайн проекта квартиры &ndash; непростая задача, особенно если она усложняется недостатками самого помещения: низкими потолками, неудачно расположенными несущими стенами, маленькими окнами. Но опытные профессионалы, работающие в нашей компании, превращают даже самые неуютные на первый взгляд квартиры в оазисы комфорта и роскоши, так необходимые жителям больших городов.</p>\r\n<p>Создание дизайн проекта квартиры начинается с обращения заказчика и включает следующие стадии:</p>\r\n<ol>\r\n<li>Планировочный этап &ndash; проектирование интерьера. На этом этапе выполняются обмеры квартиры и анализируются ее особенности. На основании этого составляется несколько вариантов планировки. При необходимости перепланировки оформляется рабочая документация.</li>\r\n<li>Стилевой этап &ndash; дизайн квартиры. Заказчик выбирает одно из планировочных решений, и на его основании разрабатываются варианты оформления. Заказчику предлагается несколько рабочих эскизов. Наиболее подходящий из них прорабатывается в деталях до тех пор, пока он не придет в соответствие с представлениями заказчика. На этом этапе также подбираются все отделочные материалы.</li>\r\n<li>Технологический этап &ndash; это составление всей рабочей документации, необходимой для реализации дизайнерских решений.</li>\r\n</ol>\r\n<p>Процесс разработки дизайн проекта сложен, требует больших затрат времени и учета многих факторов. Поэтому для его выполнения стоит прибегнуть к помощи профессионалов в этом деле. Дизайн-проект квартиры, составленный опытными специалистами нашей компании, гарантирует, что после завершения ремонта результат вас не разочарует. Чтобы внешний вид квартиры полностью соответствовал вашим ожиданиям, доверьте реализацию дизайн проекта также сотрудникам нашей компании. Заказывая полный комплекс услуг, вы сэкономите время и деньги, и с нашей помощью воплотите все фантазии об идеальной квартире.</p>','','',0,'Дизайн проект квартиры | фото и стоимость от студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(7,5,'Дизайн проект коттеджа','<p>Внутреннее наполнение дома не менее важно, чем его архитектурный облик. Большую часть времени мы проводим именно внутри, поэтому так важно сделать дом приспособленным для отдыха, семейных ужинов и встреч с друзьями.</p>\r\n<p>Предусмотреть все самостоятельно, рассчитать, где должны находиться светильники, чтобы в каждом уголке дома было светло, где &ndash; диваны и кресла в гостиной, чтобы гости могли свободно общаться, &ndash; задача не из легких. Для того чтобы в доме было приятно и комфортно, требуется грамотный дизайн проект. Кроме того, дизайн проект &ndash; это выгодное вложение средств, если вы собираетесь когда-нибудь продать свой загородный дом. Скучной прямоугольной коробкой намного сложнее заинтересовать потенциального покупателя, чем обустроенным домом с уютной атмосферой.</p>\r\n<p>Грамотная планировка коттеджа предусматривает разделение помещения на функциональные зоны. К каждому предмету имеется свободный доступ: легко открываются дверцы шкафов, удобно пользоваться стиральной машиной. В дизайн проекте, выполненном профессионалом, не будет запутанных коридоров и неиспользуемых пространств под лестницей.</p>\r\n<p>Часто владельцы домов сами не вполне точно представляют, каким они хотят видеть интерьер. В этом случае дизайнер нашей компании придет на помощь и предложит несколько стилевых направлений, на основе которых затем будет разрабатываться подробный проект.</p>\r\n<p>Учесть все факторы, которые способствуют или, наоборот, мешают гармонии и комфорту в доме, под силу только опытным профессионалам. Специалисты компании &laquo;Мастерков&raquo; предлагают квалифицированную помощь в проектировании интерьеров, их дизайнерском наполнении, составлении рабочей документации. Также наша компания поможет воплотить в жизнь проект дома вашей мечты, разработанный дизайнером на основе ваших пожеланий. Наши специалисты осуществляют все виды ремонтных и отделочных работ качественно и быстро.</p>','Дизайн-проект коттеджа','',0,'Дизайн проект коттеджа | заказать в студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(8,5,'Дизайн проект офиса','<p>Одна из важных задач руководства компании &ndash; организовать рабочее пространство своих сотрудников и сделать его эргономичным и удобным для каждого. Продуманная планировка офисного помещения &ndash; это фактор, существенно влияющий на производительность труда. Привлекательный интерьер важен и для клиентов: он производит впечатление успешности компании и располагает к сотрудничеству.</p>\r\n<p>При проектировании офиса в первую очередь важен характер работы и сфера деятельности компании. Для коллективной творческой работы необходимы открытые пространства, позволяющие совещаться в любое время. Для крупных компаний с большим числом сотрудников также предпочтительны просторные помещения, где рабочие места разделены стеллажами или шкафами. Работа, требующая сосредоточения, будет эффективной в изолированных офисах.</p>\r\n<p>Крупные бизнес центры часто имеют сложную конфигурацию стен. Это придает зданию современный облик, но создает трудности при планировке офисов. Грамотно расположить конференц-залы, приемные, кабинет руководителя могут только профессионалы. Специалисты компании &laquo;Мастерков&raquo; разработают дизайн проект офиса с учетом всех факторов: расположения лифтов, вентиляционных шахт, окон и коридоров.</p>\r\n<p>Дизайн проект офиса включает следующие этапы:</p>\r\n<ul>\r\n<li>знакомство дизайнеров с объектом, выполнение замеров, обсуждение пожеланий заказчика (стилистическое решение, цветовая гамма);</li>\r\n<li>составление эскизного решения и согласование его с заказчиком;</li>\r\n<li>детализация эскиза, подбор материалов, составление документации. По желанию клиента создается трехмерная визуализация помещения.</li>\r\n</ul>\r\n<p>Офис, привлекательный для клиентов и комфортный для сотрудников, создается в результате совместной работы заказчика и дизайнера. Специалисты компании &laquo;Мастерков&raquo; всегда внимательны к клиентам и обладают большим опытом в проектировании офисов. Кроме дизайн проекта, вы можете заказать у нас все работы по его реализации, которые будут выполнены качественно и в срок.</p>','Дизайн-проект офиса','',0,'Дизайн проект офиса | лучшие цены при заказе на сайте Мастерков','','','','',1,1,1,0,'',0,''),
(9,4,'Ремонт квартир','Раздел в разработке','','',0,'','','','','',0,1,1,0,'',0,''),
(10,9,'Демонтажные работы','<p>В понятие демонтажных работ включают снос, разрушение, разборку конструкций сооружения, связанные с невозможностью или отсутствием необходимости их дальнейшего использования. Демонтажные работы характеризуются высокой трудоёмкостью, а их стоимость составляет до 35% от общей стоимости работ.</p>\r\n<p>Как любой вид строительных работ, демонтаж конструкций имеет свою специфику. Демонтажные работы проводят в строгом соответствии с проектом производства работ, который разработан главным инженером и согласован с инженером по охране труда. Без подобной документации проведение работ не разрешается.</p>\r\n<p>Проведение демонтажных работ неопытными сотрудниками и пренебрежение правилами ТБ чреваты угрозой здоровья и жизни жильцов здания. Поэтому сложные демонтажные работы должны выполняться обязательно профессионалами с наличием допуска к таким видам работ и соответствующими разрешениями. Компания &laquo;Мастерков&raquo; поможет вам в демонтаже конструкций, быстро и качественно сделает всю работу с соблюдением проектных требований.</p>\r\n<p>К распространенным демонтажным работам относят следующие виды работ:</p>\r\n<ul>\r\n<li>демонтаж плитки;</li>\r\n<li>демонтаж стяжки;</li>\r\n<li>вырезка проёмов;</li>\r\n<li>демонтаж дверных блоков;</li>\r\n<li>демонтаж сантехники;</li>\r\n<li>снятие обоев, линолеума, паркета;</li>\r\n</ul>\r\n<p>К сложным и более трудоёмким работам можно отнести демонтаж следующих конструкций:</p>\r\n<ul>\r\n<li>стен &ndash; с сохранением прочности и устойчивости оставшихся конструкций;</li>\r\n<li>перегородок &ndash; для расширения жилого пространства. Во время этих работ следует особенно тщательно следить за сохранностью электропроводки и других коммуникаций;</li>\r\n<li>подвесных потолков, натяжных потолков, потолков из ГКЛ;</li>\r\n<li>бетонных и железобетонных конструкций. В этом случае обязательно требуется проектная документация, опытный персонал и правильная техника работ.</li>\r\n</ul>\r\n<p>Специалисты компании &laquo;Мастерков&raquo; быстро и качественно демонтируют любые конструкции и уберут весь мусор из помещения после завершения работ.</p>\r\nРаздел в разработке','Демонтажные работы','',0,'Демонтажные работы | расценки на сайте студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(11,9,'Возведение межкомнатных перегородок','<p>Возведение межкомнатных перегородок, разделяющих помещение на отдельные комнаты, является сложной работой и редко выполняется своими силами. Лучшим вариантом будет привлечение профессионалов своего дела, уже имеющих опыт работ в данной сфере. Именно такие специалисты работают в компании &laquo;Мастерков&raquo;.</p>\r\n<p>Работа начинается с проекта перепланировки помещения. Он составляется опытными специалистами, которые знают особенности демонтажа стен, знакомы с особенностями здания. Перепланировка осуществляется путём увеличения и уменьшения количества внутренних стен. При этом внешние (межквартирные) и несущие стены не должны затрагиваться вовсе.</p>\r\n<p>Во время перепланировки определяется материал, из которого будут возведены межкомнатные перегородки, подсчитывается вес и несущая способность перегородок и учитываются все правила их строительства. Такая работа под силу специалистам из &laquo;Мастерков&raquo;, которые помогут составить с нуля проект перепланировки и выполнить весь объём работ.</p>\r\n<p>Межкомнатные перегородки могут быть построены из разных материалов и служить для разных целей, но все они должны соответствовать требованиям прочности и легкости, а также обеспечивать нужный уровень звукоизоляции, удовлетворять всем санитарно-гигиеническим и противопожарным нормам. Конструктивно перегородки могут быть одно- и многослойными, а по назначению &ndash; трансформирующимися или стационарными.</p>\r\n<p>Трансформирующиеся перегородки обычно производят из лёгких материалов, например, из гипсокартона, который хорошо себя зарекомендовал в подобных работах. Преимущества данного стройматериала следующие:</p>\r\n<ul>\r\n<li>перегородки из гипсокартона легко монтировать &ndash; сроки работ существенно сокращаются;</li>\r\n<li>из этого материала можно получить перегородку любой формы, то есть сделать криволинейную стену;</li>\r\n<li>из влагостойкого гипсокартона можно делать перегородки для помещений с высокой влажностью;</li>\r\n<li>стена из гипсокартона может выдерживать до 70 кг нагрузки на погонный метр листа.</li>\r\n</ul>\r\n<p>Гипсокартонные стены ставятся на готовую стяжку, до нанесения финишного покрытия, что позволяет свободно и без лишних согласований перепланировать помещение. Ещё одним плюсом перегородок из гипсокартона является возможность провести внутри них электропроводку.</p>\r\n<p>Капитальные межкомнатные перегородки изготавливаются из других, более прочных материалов &ndash; бетон, железобетон, кирпич, пазогребневые плиты. Такие стены обладают огнеупорностью, устойчивы к влаге и имеют прекрасные теплоизоляционные показатели.</p>\r\n<p>Для проведения перепланировки в вашем доме и возведения в нём гипсокартонных межкомнатных перегородок рекомендуем обратиться в компанию &laquo;Мастерков&raquo;. Мы подготовим для вас проект перепланировки и возьмём на себя выполнение всех видов работ. Вам не придется беспокоиться за результат &ndash; он обязательно оправдает ваши ожидания.</p>','Возведение межкомнатных перегородок','',0,'Возведение межкомнатных перегородок | фото и цены на сайте студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(12,9,'Электрика','<p>Работы с электрикой требуют профессионального образования и опыта работ. При отсутствии у вас хотя бы одного из этих пунктов лучше обратиться к специалистам компании &laquo;Мастерков&raquo;, которые выполнят работу быстро и качественно, с соблюдением всех правил.</p>\r\n<p>Любая электромонтажная работа должна начинаться с планировки и подготовки чертежей. В них указано, где проходят провода и располагаются электроприборы, на каком уровне находятся розетки. Пренебрежение проектной документацией и экономия на материалах может привести к трагическим последствиям. Потому специалисты нашей компании внимательно выполняют все расчеты и используют в работе только качественные и проверенные материалы.</p>\r\n<p>В списке электромонтажных работ, выполняемых специалистами компании &laquo;Мастерков&raquo;:</p>\r\n<ul>\r\n<li>замена электрощитка;</li>\r\n<li>монтаж электропроводки, замена электропроводки, прокладка кабеля;</li>\r\n<li>замена и установка электрических и телефонных розеток, выключателей;</li>\r\n<li>ввод кабеля в помещение от ближайшего источника электроэнергии (трансформатора, столба);</li>\r\n<li>установка и замена светильников, люстр;</li>\r\n<li>монтаж внутреннего и наружного освещения;</li>\r\n<li>пусконаладочные работы;</li>\r\n<li>установка электрических счётчиков;</li>\r\n<li>подключение электрических плит, электрокаминов, обогревателей, стиральных машин.</li>\r\n</ul>\r\n<p>Перед непосредственным началом работ создаётся проект со всеми чертежами и расчётами, по которому будет работать бригада электромонтажников. Затем заготавливается весь перечень материалов: розетки, лампы, электрические коробы. По проекту делается разброска и крепление электрического кабеля, устанавливаются щитки, монтируются коробки под выключатели и розетки, производится соединение проводов в коробках.</p>\r\n<p>Особо сложные электромонтажные работы (пусконаладочные работы в автоматике, устройство наружных сетей и линий связи, устройство систем электроснабжения) обязательно требуют от исполнителя наличия специального допуска СРО. Для простых электромонтажных работ наличие допуска необязательно, но в любом случае оно служит показателем профессионализма электромонтажной фирмы и качества выполняемых работ.</p>\r\n<p>В своей работе электромонтажники руководствуются основными положениями ПТБ, ПУЭ и ПТЭ, в которых указаны все предписания по работе с электросетью и расписаны устройства электроустановок. В арсенале специалистов компании &laquo;Мастерков&raquo; &ndash; профессиональное электромонтажное оборудование, с помощью которого проводятся замеры и тесты. Качественный электромонтаж, выполненный специалистами из &laquo;Мастерков&raquo;, &ndash; залог безопасности и комфорта в вашем доме, в котором всегда будут свет и тепло.</p>','Работы с электрикой','',0,'Работы с электрикой | монтаж, замена и прокладка кабеля от студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(13,9,'Сантехника','<p>Под сантехникой подразумеваются все устройства и приборы, которые обеспечивают соблюдение санитарных и гигиенических норм в помещении. К сантехническим работам нельзя подходить безответственно, и если вы не обладаете достаточным опытом, лучше обратиться к специалистам компании &laquo;Мастерков&raquo;, имеющим большой опыт в данной сфере.</p>\r\n<p>Некоторые проблемы с сантехническим оборудованием самостоятельно решить не получится, а последствия неудачной работы с сантехникой (лопнувшая труба) доставят проблем не только вам, но и вашим соседям снизу. На материалах в сантехнических работах экономить не принято &ndash; некачественный фильтр при установке смесителя существенно сократит срок службы последнего и через некоторое время сантехника придётся вызывать вновь.</p>\r\n<p>К сантехническим работам относятся:</p>\r\n<ul>\r\n<li>монтаж систем водоснабжения и канализации;</li>\r\n<li>сварочные работы, разводка труб;</li>\r\n<li>установка, ремонт и замена унитазов, кранов, ванных, биде;</li>\r\n<li>монтаж душевых кабин;</li>\r\n<li>подключение стиральных, посудомоечных машин;</li>\r\n<li>установка бойлеров;</li>\r\n<li>замена смесителя;</li>\r\n<li>скрытая и наружная прокладка труб;</li>\r\n<li>обвязка котельной;</li>\r\n<li>установка отопительного котла;</li>\r\n<li>монтаж радиаторов;</li>\r\n<li>перенос и установка счётчиков;</li>\r\n<li>монтаж насосов и насосных станций.</li>\r\n</ul>\r\n<p>Помимо непосредственного выполнения указанных работ, сантехники компании &laquo;Мастерков&raquo; помогут вам выбрать оборудование и определить его оптимальное расположение.</p>\r\n<p>Любая сантехническая работа должна проводиться в строгом соответствии с проектной документацией и нормативами. Сложными видами работ с сантехникой считаются: изменение местоположения ванной, унитаза, раковины; подводка новой канализационной системы; подводка водоснабжения в дом. Для их проведения требуются качественные сантехнические материалы с правильно подобранными техническими характеристиками. Специалисты компании &laquo;Мастерков&raquo; выполнят все указанные виды работ. Обращение в нашу компанию гарантирует безотказную работу систем в течение нескольких лет.</p>\r\n<p>Помимо непосредственного выполнения возложенных на сантехнику функций, она выполняет немаловажную роль в общем дизайне помещения. В последнее время можно встретить экзотические ванны и раковины, выполненные из нестандартных материалов &ndash; дерево, бронза, кристаллит. С таким оборудованием привычная ванная комната приобретает дорогой, элитный вид. Специалисты по сантехническим работам из фирмы &laquo;Мастерков&raquo; помогут вам с установкой как стандартного, так и сложного оборудования, гарантируя при этом качественное исполнение с соблюдением всех нормативов.</p>','Сантехнические работы, сантехника','',0,'Сантехнические работы | расценки на ремонт сантехники на сайте Мастерков','','','','',1,1,1,0,'',0,''),
(14,9,'Стяжка пола','<p>Под стяжкой пола понимают устройство слоя из цемента и песка, который служит основой для будущего напольного покрытия. Сам процесс проводится с целью выравнивания поверхности пола, придания ему жёсткости и устойчивости, а иногда и для придания ему нужного уклона в некоторых зданиях. Также стяжка пола применяется, когда необходимо скрыть трубы или электропроводку.</p>\r\n<p>Сам процесс стяжки пола, особенно для больших помещений, трудоёмок, и самостоятельно выровнять пол не получится. Поэтому для такой работы следует обращаться к профессионалам с опытом работы. Компания &laquo;Мастерков&raquo; предлагает свою квалифицированную помощь. Наши специалисты подготовят раствор для стяжки пола, уложат его и с помощью специального оборудования выровняют поверхность.</p>\r\n<p>К основным способам выравнивания пола, применяемым в современном строительстве, относят:</p>\r\n<ul>\r\n<li>Классическую стяжку из песчано-цементной смеси. С её помощью можно добиться достаточно ровного пола, но если черновая стяжка выполнена с большими отклонениями, то для придания нужной кондиции полу может потребоваться много материала, а толстый слой и текучесть цементно-песчаной массы могут создать немало проблем.</li>\r\n<li>Сборные и насыпные полы по технологии Knauf. Эта технология обычно используется для выравнивания сильно искривленных полов. Для стяжки применяется керамзитовая крошка мелкой фракции, на которую укладываются элементы ГВЛ листов в два слоя. Для новостроек такой метод стяжки обычно не используется, но он прекрасно подходит для ремонта в старых квартирах и для устройства полов, на которых не предполагается укладка линолеума или плитки с подогревом.</li>\r\n<li>Полусухая стяжка. В основе метода лежит использование полусухой смеси из песка, цемента и пластификатора. Такая стяжка применяется в масштабных проектах и требует специального оборудования. За счёт небольшого количества воды и фиброчастиц в смеси удаётся достичь высокой скорости застывания, прочности и готовности пола к некоторым видам отделочных работ уже через 3-5 дней. Окончательное застывание поверхности происходит к концу третьей недели после заливки.</li>\r\n</ul>\r\n<p>В процессе стяжки получается ровная поверхность, на которую можно укладывать плитку, ламинат или &laquo;тёплый пол&raquo;. Специалисты компании &laquo;Мастерков&raquo; грамотно проведут стяжку пола в любых помещениях, гарантируя получение монолитного покрытия без пустот и трещин.</p>','Стяжка пола','',0,'Стяжка пола | цены на сайте студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(15,9,'Гипсокартонные работы','<p>Гипсокартонные работы некоторое время назад применялись только для возведения фальш-стен (межкомнатных перегородок) и обшивки уже существующих стен листами гипсокартона. Но со временем этот практичный и универсальный материал стал применяться и для внутренней отделки. Сегодня гипсокартонные работы помогут выровнять стены с использованием утеплителя, создать в помещении несколько арок, полок и других декоративных решений, а также смонтировать гипсокартонный подвесной потолок разнообразной формы. Все эти виды работ выполняются специалистами компании &laquo;Мастерков&raquo;, обладающими большим опытом в данной сфере.</p>\r\n<p>Гипсокартон как материал имеет ряд весомых преимуществ:</p>\r\n<ul>\r\n<li>гипсокартон удобен и прост в монтаже;</li>\r\n<li>материал экологически чист и умеет &laquo;дышать&raquo;;</li>\r\n<li>невысокая стоимость материала, низкие цены на монтаж конструкций;</li>\r\n<li>конструкции из гипсокартона способны скрыть под собой электрические, вентиляционные и сантехнические коммуникации;</li>\r\n<li>в гипсокартонные конструкции легко встроить светильники;</li>\r\n<li>перепланировка комнат с помощью гипсокартонных листов не требует согласования и большого количества проектной документации;</li>\r\n<li>гипсокартон может поставляться в различных видах (огне-, влагоупорный).</li>\r\n</ul>\r\nВот неполный список гипсокартонных работ, выполняемых специалистами компании &laquo;Мастерков&raquo;:\r\n<ul>\r\n<li>монтаж стенового каркаса из гипсокартонных профилей;</li>\r\n<li>монтаж гипсокартонных листов (ГКЛ) на стены и перегородки;</li>\r\n<li>монтаж потолочного каркаса и многоуровневых потолков из гипсокартонных профилей;</li>\r\n<li>монтаж ГКЛ под различными углами;</li>\r\n<li>устройство офисных и межкомнатных перегородок, арок из ГКЛ;</li>\r\n<li>отделка, выравнивание, шпаклёвка потолков, стен и перегородок из гипсокартона.</li>\r\n</ul>\r\n<p>Гипсокартон может быть нескольких видов, каждый из которых применяется в конкретных помещениях. Обычный гипсокартонный лист используется для отделки жилых и офисных помещений с невысоким уровнем влажности.</p>\r\n<p>Влагостойкий гипсокартонный лист применяется для отделки санузлов, ванных комнат, кухонь и для наружных работ. Устойчивость к влаге достигается за счёт силиконовых гранул и антигрибковых компонентов в гипсе. Для повышения влагозащитных характеристик лист гипсокартона покрывают водостойкой краской или грунтовкой.</p>\r\n<p>Огнестойкий гипсокартонный лист используется для отделки зданий, в которых возможна близость к открытому огню. Огнеупорность достигается за счёт добавки армирующих компонентов в состав гипса.</p>\r\n<p>Влаго- и огнестойкий лист используется в производственных помещениях с повышенными требованиями к соблюдению норм противопожарной безопасности.</p>\r\n<p>Несмотря на простоту монтажа, гипсокартон требует к себе бережного отношения, поэтому работа с ним должна проводиться квалифицированными специалистами, какими являются сотрудники компании &laquo;Мастерков&raquo;.</p>','Гипсокартонные работы','',0,'Гипсокартонные работы | цены от студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(16,9,'Малярные работы','<p>Малярные работы являются заключительным этапом ремонтных работ. Во время их выполнения малярные материалы наносятся на поверхности, обеспечивая им особый внешний вид. Малярные работы как финишная отделка поверхностей должны проводиться по завершению всех видов строительных работ. Исключением из этого правила является облицовка пола (укладка ламината, паркета, линолеума).</p>\r\n<p>Малярные работы требуют особого профессионального подхода, поскольку некачественная отделка и покраска поверхностей потребуют в дальнейшем больших сил и средств на устранение недостатков. Лучше сразу обратиться к специалистам компании &laquo;Мастерков&raquo;, которые качественно и в срок произведут малярные работы любой сложности и для любых покрытий. Наши специалисты также помогут вам определиться с перечнем материалов, составят проект малярных работ.</p>\r\n<p>Малярные работы подразделяются на следующие виды:</p>\r\n<ul>\r\n<li>в зависимости от условий выполнения работы &ndash; на наружные и внутренние;</li>\r\n<li>по виду связующего составляющего &ndash; с использованием водных и масляных красок;</li>\r\n<li>по качеству производимых работ &ndash; на отделку под обои, декоративные краски и штукатурки;</li>\r\n<li>в зависимости от типа окрашиваемых поверхностей &ndash; работы по бетону, дереву, металлу, штукатурке.</li>\r\n</ul>\r\n<p>Все малярные работы состоят из следующих этапов:</p>\r\n<ul>\r\n<li>Приготовление лакокрасочных составов, выбор цвета и типа краски под отделку. Особое внимание следует уделить цвету краски &ndash; он выбирается в соответствии с дизайн проектом помещения. Неправильно выбранный цвет лишит интерьер гармонии и благородства.</li>\r\n<li>Подготовка поверхности под окраску: шпатлевание (устранение дефектов поверхности для придания ровного состояния), очистку от пыли, жирных пятен и ржавчины, грунтование (покрытие составами, которые улучшают покрытие поверхности краской).</li>\r\n<li>Окраска поверхности. Она может проводиться как вручную, с помощью валиков, так и с использованием распылителей (пульверизаторов и краскопультов).</li>\r\n</ul>\r\n<p>Специалисты компании &laquo;Мастерков&raquo; гарантируют качественное и грамотное проведение всех этапов малярных работ.</p>','','',0,'Малярные работы | стоимость на сайте студии ремонта Мастерков','','','malyarnye-raboty','',1,1,1,0,'',0,''),
(17,9,'Плиточные работы','<p>Плиточные работы являются одной из составляющей косметического ремонта и отделки помещений. Процесс укладки плитки требует профессионального подхода: неопытная укладка и малейшая неточность испортят всю гармоничную картину интерьера, а для устранения ошибки потребуются большие затраты.</p>\r\n<p>Напольное покрытие подвергается интенсивным механическим нагрузкам, поэтому большое значение имеет выбор материала, из которого сделана плитка. Чтобы получить гарантированно высокий результат, оправдывающий ваши ожидания, обратитесь за помощью к квалифицированным специалистам из &laquo;Мастерков&raquo;. Мы поможем вам определиться с типом напольного или настенного покрытия, составим проект и займёмся выполнением всех видов плиточных работ. Спектр плиточных работ включает в себя:</p>\r\n<ul>\r\n<li>резку плитки;</li>\r\n<li>сверление отверстий в плитке;</li>\r\n<li>укладку облицовочных материалов: мозаика, керамогранит, керамическая плитка.</li>\r\n</ul>\r\n<p>При отделке сложных геометрических поверхностей следует уделять внимание качеству межплиточных швов. При малейших зазорах и трещинах под плитку начнёт просачиваться влага. Некачественная укладка и затирка в этом случае приведут к тому, что плитка быстро отпадет от основы. Все проблемы с неровной поверхностью будут решены специалистами &laquo;Мастерков&raquo;. Они произведут все расчеты и под вашим контролем и наблюдением аккуратно выполнят все отделочные работы.</p>\r\n<p>Плитку обычно кладут на пол и стены в ванной комнате, в туалете и на кухне. Так как уровень влажности там выше, чем в других комнатах, потребуется предварительная подготовка стен и пола. Старая поверхность обязательно должна быть демонтирована, обработана специальными химическими составами и зачищена для нанесения водостойкого клея. Шов между плитками должен быть идеально ровным, а рисунок на них &ndash; точно соблюдён. Все эти требования, свидетельствующие о высоком качестве работ, в обязательном порядке соблюдаются специалистами студии ремонта &laquo;Мастерков&raquo; &ndash; настоящими профессионалами своего дела.</p>','','',0,'Плиточные работы | цены и фото на сайте студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(18,9,'Плотницкие работы','<p>Плотницкие работы затрагивают практически все помещения внутри дома. Общее у них &ndash; работа с деревом или похожими на него материалами. Квалифицированный плотник является мастером на все руки и оказывает следующие виды услуг:</p>\r\n<ul>\r\n<li>монтаж и замена межкомнатных дверей (двойных и одинарных), установка петель, врезка замков;</li>\r\n<li>изготовление порожков дверей и опалубки;</li>\r\n<li>укладка паркетной доски и ламината;</li>\r\n<li>установка корпусных арок и перегородок из гипсокартона;</li>\r\n<li>монтаж подоконников, карнизов;</li>\r\n<li>сборка и разборка, ремонт мебели;</li>\r\n<li>изготовление полок, ниш и антресолей;</li>\r\n</ul>\r\n<p>В загородных деревянных коттеджах работы у плотника ещё больше:</p>\r\n<ul>\r\n<li>Отделка пола. В это понятие включается монтаж лаг, чистового и чернового пола, настил половых покрытий, укладка паркета, шлифовка деревянной поверхности и подготовка пола под покраску.</li>\r\n<li>Отделка потолка. Плотник занимается установкой потолочных балок, подшивкой обрешетки, отделкой блокхаусом, вагонкой и шлифовкой поверхностей под покраску.</li>\r\n<li>Отделка стен. Профессионалы &laquo;Мастерков&raquo; осуществляют наружную и внутреннюю обработку стен деревянного дома &ndash; строгание и обшивку стен.</li>\r\n<li>Установка дверей. Один из самых трудоёмких видов плотницких работ, требующий профессионального подхода. Включает в себя подготовку дверного проёма, монтаж дверной коробки, установку дверного полотна, врезку петель, замков.</li>\r\n<li>Установка окон. Сюда относится пропил сруба для оконного проёма, установка оконного блока вместе с монтажом подоконников.</li>\r\n</ul>\r\n<p>Ввиду дороговизны материалов в плотницком деле важно доверить работу настоящему опытному профессионалу, какими являются плотники фирмы &laquo;Мастерков&raquo;.</p>\r\n<p>Изделия из дерева и деревянные покрытия сейчас переживают второй пик популярности. Дерево отлично держит тепло и впитывает влагу, отдавая ее, когда воздух сухой, &ndash; иначе говоря, поддерживает микроклимат в помещении. Мало какой стройматериал смотрится так же благородно и солидно, как дерево. Поэтому ламинат в качестве напольного покрытия удерживает первенство в своей категории. Мастера-плотники компании &laquo;Мастерков&raquo; имеют большой опыт в укладке ламината и вовремя выполнят любой заказ клиента.</p>\r\n<p>К плотницким работам также относится и работа с гипсокартоном. В руках профессионалов он превращается в межкомнатные перегородки, навесные потолки и ровные стены. Плотницкие работы любого типа &ndash; то, с чём профессионалы компании &laquo;Мастерков&raquo; всегда справятся на &laquo;отлично&raquo;!</p>','Плотницкие работы','',0,'Плотницкие работы | расценки от студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(19,9,'Поклейка обоев, нанесение декоративных покрытий','<p>Работы по поклейке обоев включают в себя следующие этапы:</p>\r\n<ul>\r\n<li>вне зависимости от выбранного вида обоев поклейка начинается с подготовки стен &ndash; выравнивания, нанесения штукатурки, грунтовки;</li>\r\n<li>на стены с помощью отвеса наносится ориентир для поклейки первого листа;</li>\r\n<li>от рулонов отрезают несколько полотнищ нужной длины;</li>\r\n<li>готовится обойный клей;</li>\r\n<li>клей наносится на изнаночную сторону полотнища;</li>\r\n<li>обои клеятся к стене и разглаживаются с помощью валика. Остатки клея удаляются с поверхности обоев.</li>\r\n</ul>\r\n<p>Поклейка обоев обычно производится в четыре руки. Один человек занимается приклеиванием обоев к стене, другой &ndash; совмещением краёв. Окна во время поклейки лучше полностью закрывать, так как сквозняк приводит к неравномерному высыханию клея на разных участках. Это приведёт к перекосам и последующему отклеиванию обоев от поверхности стен.</p>\r\n<p>Самостоятельная поклейка обоев &ndash; дело трудоёмкое и утомительное, поэтому лучше доверить его профессионалам компании &laquo;Мастерков&raquo;, имеющим большой опыт работы. Вам же останется только наблюдать за тем, как голые стены преображаются у вас на глазах, а комната становится уютной и красивой.</p>\r\n<p>Среди многообразия обоев выделяют следующие виды:</p>\r\n<ul>\r\n<li>Бумажные &ndash; отлично подходят для любого жилого помещения, пропускают воздух, стоят дешево и могут приклеиваться любым клеем. В то же время они чувствительны к прямым солнечным лучам и боятся высокой влажности. При поклейке бумажных обоев следует действовать аккуратно и быстро, не допуская раскисания.</li>\r\n<li>Виниловые &ndash; состоят из двух слоёв: прочной бумаги и ПВХ-плёнки на поверхности. Такие обои прочнее бумажных, нетоксичны, устойчивы к грибкам и могут эксплуатироваться много лет. Виниловые обои легко могут огибать неровности и углы и растягиваться в трудных местах. Вода, солнечные лучи и грязь им не страшны.</li>\r\n<li>Флизелиновые &ndash; вместо бумажной основы имеют флизелиновую, не требуют нанесения клея.</li>\r\n<li>Текстильные &ndash; их верхний слой состоит из текстильного полотна (шёлк, лён, вискоза). С дизайнерской точки зрения &ndash; это лучший выбор обоев, так как они позволяют воплотить оригинальные идеи. Но такие обои подвержены истиранию и требуют бережного обращения.</li>\r\n</ul>\r\n<p>Для каждого из этих видов требуется свой клей. Для бумажных обоев он самый дешёвый и простой в использовании. Виниловый клей может применяться помимо виниловых обоев и для текстильных, бамбуковых, текстурных. Благодаря скользящей текстуре недавно приклеенную виниловым клеем полосу можно переклеить или передвинуть.</p>','Поклейка обоев','',0,'Подготовка стен и поклейка обоев | стоимость на сайте студии ремонта Мастерков','','','','',1,1,1,0,'',0,''),
(20,0,'Цены','Раздел в разработке','','',0,'','','','','',0,0,1,0,'',0,'')	;
#	TC`poll_ans`utf8_general_ci	;
CREATE TABLE `poll_ans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_q` int(11) NOT NULL,
  `ans` text CHARACTER SET cp1251 NOT NULL,
  `polls` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`polls`utf8_general_ci	;
CREATE TABLE `polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quest` text CHARACTER SET cp1251 NOT NULL,
  `active` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`price`utf8_general_ci	;
CREATE TABLE `price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `shortdesc` text NOT NULL,
  `desc` text NOT NULL,
  `price` int(11) NOT NULL,
  `vol` varchar(255) NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `new` int(2) NOT NULL DEFAULT '0',
  `spec` int(2) NOT NULL DEFAULT '0',
  `teh` text NOT NULL,
  `valute` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`price_cat`utf8_general_ci	;
CREATE TABLE `price_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL,
  `name` text NOT NULL,
  `desc` text NOT NULL,
  `iconExt` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`price_img`utf8_general_ci	;
CREATE TABLE `price_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`pricelistfiles`utf8_general_ci	;
CREATE TABLE `pricelistfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catalog` enum('0','1') NOT NULL DEFAULT '0',
  `date` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `fulldesc` text NOT NULL,
  `ext` varchar(255) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0',
  `mark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`reviews`utf8_general_ci	;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `homepage` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `answer` text NOT NULL,
  `active` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TC`settings_shop`utf8_general_ci	;
CREATE TABLE `settings_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` text CHARACTER SET cp1251 NOT NULL,
  `value` text CHARACTER SET cp1251 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_attach`utf8_general_ci	;
CREATE TABLE `shop_attach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `attach` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`shop_attach`utf8_general_ci	;
INSERT INTO `shop_attach` VALUES 
(2,3,0),
(3,3,2),
(4,5,2)	;
#	TC`shop_brands`utf8_general_ci	;
CREATE TABLE `shop_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_cat`utf8_general_ci	;
CREATE TABLE `shop_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL,
  `name` text CHARACTER SET cp1251 NOT NULL,
  `pos` int(11) NOT NULL,
  `desc` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `TitlePage` varchar(1000) NOT NULL,
  `DescPage` varchar(1000) NOT NULL,
  `KeysPage` varchar(1000) NOT NULL,
  `descTop` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_colors`utf8_general_ci	;
CREATE TABLE `shop_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_colors_values`utf8_general_ci	;
CREATE TABLE `shop_colors_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_delivery`utf8_general_ci	;
CREATE TABLE `shop_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` float(11,2) NOT NULL DEFAULT '0.00',
  `active` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  `price2` float(11,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_dop`cp1251_general_ci	;
CREATE TABLE `shop_dop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sv` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`shop_dop_values`cp1251_general_ci	;
CREATE TABLE `shop_dop_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`shop_favorite`utf8_general_ci	;
CREATE TABLE `shop_favorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `iditem` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_fullness`utf8_general_ci	;
CREATE TABLE `shop_fullness` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_fullness_values`utf8_general_ci	;
CREATE TABLE `shop_fullness_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_images`utf8_general_ci	;
CREATE TABLE `shop_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_items`utf8_general_ci	;
CREATE TABLE `shop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  `art` text CHARACTER SET cp1251 NOT NULL,
  `name` text CHARACTER SET cp1251 NOT NULL,
  `prim` varchar(255) NOT NULL,
  `shortdesc` text CHARACTER SET cp1251 NOT NULL,
  `fulldesc` text CHARACTER SET cp1251 NOT NULL,
  `price_rozn` int(11) NOT NULL DEFAULT '0',
  `price_opt` int(11) NOT NULL DEFAULT '0',
  `kol` varchar(255) NOT NULL DEFAULT '0',
  `mark` int(11) NOT NULL DEFAULT '0',
  `mark_eng` varchar(255) NOT NULL,
  `post` text NOT NULL,
  `photo` text CHARACTER SET cp1251 NOT NULL,
  `onindex` int(11) NOT NULL,
  `onlider` int(11) NOT NULL,
  `onsells` int(11) NOT NULL,
  `onecs` int(11) NOT NULL DEFAULT '0',
  `TitlePage` text NOT NULL,
  `DescPage` text NOT NULL,
  `KeysPage` text NOT NULL,
  `sleeve_length` enum('-1','0','1','2') NOT NULL DEFAULT '-1',
  `length` enum('-1','0','1','2') NOT NULL DEFAULT '-1',
  `delivery` enum('-1','0','1') NOT NULL DEFAULT '-1',
  `rating` int(11) NOT NULL DEFAULT '0',
  `caring` text NOT NULL,
  `deliveryDesc` text NOT NULL,
  `sizesDesc` text NOT NULL,
  `stock` enum('0','1') NOT NULL DEFAULT '0',
  `dateTo` date NOT NULL,
  `timeTo` time NOT NULL,
  `youtube` text NOT NULL,
  `new` enum('0','1') NOT NULL DEFAULT '0',
  `bestsell` enum('0','1') NOT NULL DEFAULT '0',
  `editorChoice` enum('0','1') NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `recom` text NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_items_comments`utf8_general_ci	;
CREATE TABLE `shop_items_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_items_comments_img`utf8_general_ci	;
CREATE TABLE `shop_items_comments_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_items_dop`utf8_general_ci	;
CREATE TABLE `shop_items_dop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL,
  `title` text CHARACTER SET cp1251 NOT NULL,
  `desc` text CHARACTER SET cp1251 NOT NULL,
  `keys` text CHARACTER SET cp1251 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_items_rating`utf8_general_ci	;
CREATE TABLE `shop_items_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_orders`utf8_general_ci	;
CREATE TABLE `shop_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `time` varchar(255) NOT NULL DEFAULT '',
  `sk` int(11) NOT NULL DEFAULT '0',
  `suma` float(11,2) NOT NULL DEFAULT '0.00',
  `date` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `index` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `house` varchar(255) NOT NULL,
  `korpus` varchar(255) NOT NULL,
  `podezd` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `kv` varchar(255) NOT NULL,
  `obhvati` text NOT NULL,
  `comment` text NOT NULL,
  `delivery` varchar(255) NOT NULL,
  `delivery_price` float(11,2) NOT NULL DEFAULT '0.00',
  `domofon` varchar(1000) NOT NULL,
  `flat` varchar(1000) NOT NULL,
  `payment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_orders_items`utf8_general_ci	;
CREATE TABLE `shop_orders_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_order` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `art` text NOT NULL,
  `name` text CHARACTER SET cp1251 NOT NULL,
  `price_rozn` float(11,2) NOT NULL DEFAULT '0.00',
  `price_opt` float(11,2) NOT NULL DEFAULT '0.00',
  `kol` int(11) NOT NULL DEFAULT '1',
  `color` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `fullness` varchar(255) NOT NULL,
  `style` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_post`utf8_general_ci	;
CREATE TABLE `shop_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `last_upd` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_sizes`utf8_general_ci	;
CREATE TABLE `shop_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_sizes_values`utf8_general_ci	;
CREATE TABLE `shop_sizes_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `store` enum('0','1','2','3') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_sk_users`cp1251_general_ci	;
CREATE TABLE `shop_sk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `sk` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`shop_style`utf8_general_ci	;
CREATE TABLE `shop_style` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_style_values`utf8_general_ci	;
CREATE TABLE `shop_style_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_tmp`utf8_general_ci	;
CREATE TABLE `shop_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `art` text CHARACTER SET cp1251 NOT NULL,
  `name` text CHARACTER SET cp1251 NOT NULL,
  `shortdesc` text CHARACTER SET cp1251 NOT NULL,
  `fulldesc` text CHARACTER SET cp1251 NOT NULL,
  `price_rozn` float(11,2) NOT NULL DEFAULT '0.00',
  `price_opt` float(11,2) NOT NULL DEFAULT '0.00',
  `kol` text CHARACTER SET cp1251 NOT NULL,
  `mark` text CHARACTER SET cp1251 NOT NULL,
  `mark_eng` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `photo` text CHARACTER SET cp1251 NOT NULL,
  `onindex` int(11) NOT NULL,
  `onlider` int(11) NOT NULL,
  `onsells` int(11) NOT NULL,
  `onecs` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`shop_users`utf8_general_ci	;
CREATE TABLE `shop_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `birthday` date NOT NULL DEFAULT '1950-01-01',
  `work` int(3) NOT NULL DEFAULT '0',
  `phone_code` varchar(4) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `org` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` int(11) NOT NULL DEFAULT '1',
  `raion` varchar(255) NOT NULL,
  `oblast` varchar(255) NOT NULL,
  `country` int(11) NOT NULL DEFAULT '174',
  `zip` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `house` varchar(255) NOT NULL,
  `korp` varchar(255) NOT NULL,
  `flat` varchar(255) NOT NULL,
  `sk` int(11) NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `IPReg` varchar(255) NOT NULL,
  `IPLast` varchar(255) NOT NULL,
  `Mailed` int(11) NOT NULL DEFAULT '1',
  `Type` int(4) NOT NULL DEFAULT '0',
  `TypeText` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`site_setting`utf8_general_ci	;
CREATE TABLE `site_setting` (
  `option` varchar(255) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`site_setting`utf8_general_ci	;
INSERT INTO `site_setting` VALUES 
('title',''),
('desc',''),
('keys',''),
('email_admin','info@masterkov.ru'),
('sk','0')	;
#	TC`slider`utf8_general_ci	;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `pageLink` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`slider`utf8_general_ci	;
INSERT INTO `slider` VALUES 
(6,0,1,'0000-00-00','slide3','','','','','',1,''),
(5,0,3,'0000-00-00','slide2','','','','','',1,''),
(4,0,2,'0000-00-00','slide1','','','','','',1,'')	;
#	TC`slider_img`utf8_general_ci	;
CREATE TABLE `slider_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`slider_img`utf8_general_ci	;
INSERT INTO `slider_img` VALUES 
(7,6,'jpg',0,0),
(5,5,'jpg',0,0),
(4,4,'jpg',0,0)	;
#	TC`specialists`utf8_general_ci	;
CREATE TABLE `specialists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`specialists_img`utf8_general_ci	;
CREATE TABLE `specialists_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`stat`utf8_general_ci	;
CREATE TABLE `stat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(255) NOT NULL,
  `module_id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `region` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `dolg` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`tips`utf8_general_ci	;
CREATE TABLE `tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`userform`cp1251_general_ci	;
CREATE TABLE `userform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) NOT NULL,
  `xtype` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fieldLabel` varchar(255) NOT NULL,
  `allowBlank` varchar(255) NOT NULL,
  `vtype` varchar(255) NOT NULL,
  `blankText` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`userform_check_items`cp1251_general_ci	;
CREATE TABLE `userform_check_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcheck` int(11) NOT NULL,
  `boxLabel` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`userform_formatfiles`cp1251_general_ci	;
CREATE TABLE `userform_formatfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idfile` int(11) NOT NULL,
  `formats` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`userform_values`cp1251_general_ci	;
CREATE TABLE `userform_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idfield` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` text NOT NULL,
  `password` text NOT NULL,
  `pages` enum('0','1') NOT NULL DEFAULT '0',
  `blocks` enum('0','1') NOT NULL DEFAULT '0',
  `news` enum('0','1') NOT NULL DEFAULT '0',
  `articles` enum('0','1') NOT NULL DEFAULT '0',
  `price` enum('0','1') NOT NULL DEFAULT '1',
  `faq` enum('0','1') NOT NULL DEFAULT '0',
  `files` enum('0','1') NOT NULL DEFAULT '0',
  `banners` enum('0','1') NOT NULL DEFAULT '0',
  `slider` enum('0','1') NOT NULL DEFAULT '0',
  `pricelistfiles` enum('0','1') NOT NULL DEFAULT '0',
  `newsletter` enum('0','1') NOT NULL DEFAULT '0',
  `users` enum('0','1') NOT NULL DEFAULT '0',
  `site_settings` enum('0','1') NOT NULL DEFAULT '0',
  `UploadFiles` enum('0','1') NOT NULL DEFAULT '0',
  `shop` enum('0','1') NOT NULL DEFAULT '0',
  `systemusers` enum('0','1') NOT NULL DEFAULT '0',
  `reviews` enum('0','1') NOT NULL DEFAULT '0',
  `active` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(2,'admin','85587e3aa839ec03b0967408ca2192f9','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1'),
(4,'lexx','10321c9d7929049973e35b825e22d41c','1','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','1')	;
#	TC`users_portal`cp1251_general_ci	;
CREATE TABLE `users_portal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251	;
#	TC`video`utf8_general_ci	;
CREATE TABLE `video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `utube` varchar(255) NOT NULL,
  `notice` text NOT NULL,
  `desc` text NOT NULL,
  `TitlePage` varchar(255) NOT NULL,
  `DescPage` varchar(255) NOT NULL,
  `KeysPage` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`video_img`utf8_general_ci	;
CREATE TABLE `video_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iditem` int(11) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `osn` int(11) NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`widgets`utf8_general_ci	;
CREATE TABLE `widgets` (
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
